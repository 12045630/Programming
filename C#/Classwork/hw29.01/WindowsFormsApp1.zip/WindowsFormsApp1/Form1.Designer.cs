﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toode = new System.Windows.Forms.Label();
            this.toodebox = new System.Windows.Forms.TextBox();
            this.kogusbox = new System.Windows.Forms.TextBox();
            this.kogus = new System.Windows.Forms.Label();
            this.hindbox = new System.Windows.Forms.TextBox();
            this.hind = new System.Windows.Forms.Label();
            this.filebox = new System.Windows.Forms.TextBox();
            this.file = new System.Windows.Forms.Label();
            this.addbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label1.Location = new System.Drawing.Point(278, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Andmebaas";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(196, 83);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(551, 227);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // toode
            // 
            this.toode.AutoSize = true;
            this.toode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.toode.Location = new System.Drawing.Point(24, 127);
            this.toode.Name = "toode";
            this.toode.Size = new System.Drawing.Size(59, 20);
            this.toode.TabIndex = 2;
            this.toode.Text = "Toode";
            // 
            // toodebox
            // 
            this.toodebox.Location = new System.Drawing.Point(104, 127);
            this.toodebox.Name = "toodebox";
            this.toodebox.Size = new System.Drawing.Size(61, 20);
            this.toodebox.TabIndex = 3;
            this.toodebox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // kogusbox
            // 
            this.kogusbox.Location = new System.Drawing.Point(104, 153);
            this.kogusbox.Name = "kogusbox";
            this.kogusbox.Size = new System.Drawing.Size(61, 20);
            this.kogusbox.TabIndex = 5;
            // 
            // kogus
            // 
            this.kogus.AutoSize = true;
            this.kogus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.kogus.Location = new System.Drawing.Point(24, 153);
            this.kogus.Name = "kogus";
            this.kogus.Size = new System.Drawing.Size(59, 20);
            this.kogus.TabIndex = 4;
            this.kogus.Text = "Kogus";
            // 
            // hindbox
            // 
            this.hindbox.Location = new System.Drawing.Point(104, 179);
            this.hindbox.Name = "hindbox";
            this.hindbox.Size = new System.Drawing.Size(61, 20);
            this.hindbox.TabIndex = 7;
            // 
            // hind
            // 
            this.hind.AutoSize = true;
            this.hind.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.hind.Location = new System.Drawing.Point(24, 179);
            this.hind.Name = "hind";
            this.hind.Size = new System.Drawing.Size(46, 20);
            this.hind.TabIndex = 6;
            this.hind.Text = "Hind";
            // 
            // filebox
            // 
            this.filebox.Location = new System.Drawing.Point(104, 205);
            this.filebox.Name = "filebox";
            this.filebox.Size = new System.Drawing.Size(61, 20);
            this.filebox.TabIndex = 9;
            // 
            // file
            // 
            this.file.AutoSize = true;
            this.file.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.file.Location = new System.Drawing.Point(24, 205);
            this.file.Name = "file";
            this.file.Size = new System.Drawing.Size(38, 20);
            this.file.TabIndex = 8;
            this.file.Text = "File";
            // 
            // addbtn
            // 
            this.addbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.addbtn.Location = new System.Drawing.Point(196, 316);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(85, 32);
            this.addbtn.TabIndex = 10;
            this.addbtn.Text = "Lisa";
            this.addbtn.UseVisualStyleBackColor = true;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.filebox);
            this.Controls.Add(this.file);
            this.Controls.Add(this.hindbox);
            this.Controls.Add(this.hind);
            this.Controls.Add(this.kogusbox);
            this.Controls.Add(this.kogus);
            this.Controls.Add(this.toodebox);
            this.Controls.Add(this.toode);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "DataBase";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label toode;
        private System.Windows.Forms.TextBox toodebox;
        private System.Windows.Forms.TextBox kogusbox;
        private System.Windows.Forms.Label kogus;
        private System.Windows.Forms.TextBox hindbox;
        private System.Windows.Forms.Label hind;
        private System.Windows.Forms.TextBox filebox;
        private System.Windows.Forms.Label file;
        private System.Windows.Forms.Button addbtn;
    }
}

